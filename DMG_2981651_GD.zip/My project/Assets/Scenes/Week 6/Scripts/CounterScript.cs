using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.TextCore;


public class CounterScript : MonoBehaviour
{
    // Start is called before the first frame update
    public TMP_Text UItext;
    public int numSaved = 0;
    
    void Start()
    {
        UItext = GetComponent<TMP_Text>();
    }

    // Update is called once per frame
    void Update()
    {
        UItext.text = ("Astronauts Saved: " + numSaved);
        if (UItext != null) {
            
        }
    }
}
