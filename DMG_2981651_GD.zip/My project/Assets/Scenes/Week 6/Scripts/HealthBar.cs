using UnityEngine;
using UnityEngine.UI;

public class HealthBar : MonoBehaviour
{
    public Slider slider;
    public float maxHealth = 100f;
    public float currentHealth;
    public Color lowHealthColor;
    
    void Start()
    {
        currentHealth = maxHealth;
        slider.maxValue = maxHealth;
        slider.value = currentHealth;
    }

    public void TakeDamage(float damage)
    {
        currentHealth -= damage;
        UpdateHealthBar();
    }

    void UpdateHealthBar()
    {
        slider.value = currentHealth;
        if (currentHealth <= maxHealth * 0.25f)
        {
            slider.fillRect.GetComponentInChildren<Image>().color = lowHealthColor;
        }
    }
}
