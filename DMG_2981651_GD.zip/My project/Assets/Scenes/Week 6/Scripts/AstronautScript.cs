using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AstronautScript : MonoBehaviour
{
    public float rotationSpeed;
    private bool isSaved = false;
    public CounterScript counter;
    
    // Update is called once per frame
    void Update()
    {
        transform.Rotate(Vector3.forward * rotationSpeed * Time.deltaTime);
    }
    void OnTriggerEnter2D(Collider2D collison)
    {
        if (collison.gameObject.tag == "Player" && !isSaved)
        {
            isSaved = true;
            //GetComponent<SpriteRenderer>().enabled = false;
            counter.numSaved++;
            transform.position = new Vector3(Random.Range(-11f, 11f), Random.Range(-3f, 3f), 96);
            isSaved = false;
            
        }
    }
}
