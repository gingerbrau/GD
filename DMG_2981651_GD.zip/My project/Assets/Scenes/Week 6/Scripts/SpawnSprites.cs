using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SpawnSprites : MonoBehaviour
{
    public GameObject Astronaut;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            print("randomiser called");
            // Generate a random position within the screen bounds
            Vector2 randomPos = new Vector2(Random.Range(-5f, 5f), Random.Range(-5f, 5f));

            // Create a new instance of the sprite prefab at the random position
            Instantiate(Astronaut, randomPos, Quaternion.identity);
        }
    }
}