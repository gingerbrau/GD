using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerScript : MonoBehaviour
{
    //buttons
    public Button downButton;
    public Button upButton;
    public Button leftButton;
    public Button rightButton;
    
    //slider
    public float maxHealth = 100f;
    public float currentHealth;
    public Slider healthSlider;
    
    // Start is called before the first frame update

    public void Start()
    {
        downButton.onClick.AddListener(DownButtonBehavour);
        upButton.onClick.AddListener(UpButtonBehavour);
        leftButton.onClick.AddListener(LeftButtonBehavour);
        rightButton.onClick.AddListener(RightButtonBehavour);
        
        currentHealth = maxHealth;
        healthSlider.maxValue = maxHealth;
        healthSlider.value = currentHealth;
    
    }
    public void UpButtonBehavour()
    {
        transform.position += new Vector3(0, 2, 0);
        //Debug.Log("Button Clicked");
    }
    
    void DownButtonBehavour()
    {
        transform.position += new Vector3(0, -2, 0);
    }
    
    void LeftButtonBehavour()
    {
        transform.position += new Vector3(-2, 0, 0);
    }
    
    void RightButtonBehavour()
    {
        transform.position += new Vector3(2, 0, 0);
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Enemy")
        {
            print("Hit");
            TakeDamage(10);
        }
    }

    void TakeDamage(float damage)
    {
        currentHealth -= damage;
        healthSlider.value = currentHealth;

        if (currentHealth <= 0)
        {
            print("Game Over");
        }

        if (currentHealth <= maxHealth * 0.25f)
        {
            healthSlider.fillRect.GetComponentInChildren<Image>().color = Color.red;
        }
    }
}
