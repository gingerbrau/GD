using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DownButtonBehavour : MonoBehaviour


{

    // Start is called before the first frame update

    public void MoveDown()
    {
        transform.position += new Vector3(0, -25, 0);
    }
}
