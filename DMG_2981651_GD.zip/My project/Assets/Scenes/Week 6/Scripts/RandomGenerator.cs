using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RandomGenerator : MonoBehaviour

{
    public float speed = 5f;

    void Start()
    {
        // Set initial position on a random y coordinate
        float randomY = Random.Range(-130f, 130f);
        transform.position = new Vector3(transform.position.x, randomY, transform.position.z);
    }

    void Update()
    {
        // Move the sprite left
        transform.Translate(-speed * Time.deltaTime, 0, 0);
    }
}
