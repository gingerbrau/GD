using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UpButtonBehavour : MonoBehaviour
{
    
    public void MoveUp()
    {
        transform.position += new Vector3(0, 25, 0);
        //Debug.Log("Button Clicked");
    }
}
