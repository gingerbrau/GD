using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UpdateCounterScript : MonoBehaviour
{
    void OnTriggerEnter2D(Collider2D col)
        {
            switch (this.gameObject.name)
            {   
                case "Astronaut":
                    CounterScript counterScript = FindObjectOfType<CounterScript>();
                    counterScript.numSaved += 1;
                    break;
            }
        }
    }
