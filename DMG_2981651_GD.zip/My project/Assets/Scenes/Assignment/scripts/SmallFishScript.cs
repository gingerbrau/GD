using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SmallFishScript : MonoBehaviour
{
    public float speed;
    public float swimDistance;
    private bool facingRight = true;
    private Vector3 startPos;
    private Vector3 leftPos;
    private Vector3 rightPos;
    public Transform playerTransform;
    public float swimAwayDistance;
    public float scatterDistance;

    private void Start()
    {
        startPos = transform.position;
        leftPos = new Vector3(startPos.x - swimDistance / 2, startPos.y, startPos.z);
        rightPos = new Vector3(startPos.x + swimDistance / 2, startPos.y, startPos.z);
    }

    private void Update()
    {
        float distanceToPlayer = Vector3.Distance(transform.position, playerTransform.position);
    
        Vector3 targetPos;
        if (distanceToPlayer < swimAwayDistance)
        {
            Vector3 direction = (transform.position - playerTransform.position).normalized;
            direction.z = 0f;
            targetPos = transform.position + direction * scatterDistance;
        }
        else
        {
            targetPos = facingRight ? rightPos : leftPos;
        }

        transform.position = Vector3.MoveTowards(transform.position, targetPos, speed * Time.deltaTime);

        if (transform.position.x > rightPos.x - 0.1f && facingRight)
        {
            Flip();
        }
        else if (transform.position.x < leftPos.x + 0.1f && !facingRight)
        {
            Flip();
        }
    }

    private void Flip()
    {
        facingRight = !facingRight;
        Vector3 theScale = transform.localScale;
        theScale.x *= -1;
        transform.localScale = theScale;
    }
}