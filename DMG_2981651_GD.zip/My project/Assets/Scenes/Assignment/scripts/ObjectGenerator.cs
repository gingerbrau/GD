using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectGenerator : MonoBehaviour
{
    public GameObject[] objectPrefabs;
    public int maxObjects;
    public UITextCollectionsScript itemsLeftText;
    public UITextController uiTextController;
    private int numLeft;
    public float bobbingSpeed;
    public float bobbingHeight;

    private void Start()
    {
        print(
            "Welcome to my game based on the concept of dredging. Your task is to clean up the ocean. Each item collected will increase your score. Press space for a burst of speed.");
        // Generate a random number of objects
        int numObjects = Random.Range(1, maxObjects + 1);
        numLeft = numObjects;
        itemsLeftText.SetNumLeft(numLeft);

        // Instantiate objects at random positions within the specified range
        for (int i = 0; i < numObjects; i++)
        {
            // Select a random object from the array of object prefabs
            GameObject objectPrefab = objectPrefabs[Random.Range(0, objectPrefabs.Length)];

            // Generate a random position within the specified range
            float xPos = Random.Range(-20, 220);
            float yPos = Random.Range(-220, 20);
            Vector3 position = new Vector3(xPos, yPos, 0f);

            // Instantiate the object at the random position
            //Instantiate(objectPrefab, position, Quaternion.identity);
            GameObject obj = Instantiate(objectPrefab, position, Quaternion.identity);

            // Attach the Bobbing script to the object
            Bobbing bobbingScript = obj.AddComponent<Bobbing>();
            bobbingScript.speed = bobbingSpeed;
            bobbingScript.height = bobbingHeight;
        }
    }

    public void ItemPickedUp(GameObject item)
    {
        if (item.CompareTag("Bottle"))
        {
            uiTextController.Score += 5;
        }
        else if (item.CompareTag("Paper"))
        {
            uiTextController.Score += 1;
        }
        else if (item.CompareTag("BinBag"))
        {
            uiTextController.Score += 10;
        }
    
        numLeft--;
        itemsLeftText.SetNumLeft(numLeft);
        itemsLeftText.UpdateText();
    }
}