using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class parallex : MonoBehaviour
{
	public Transform[] backgrounds;
    public float[] parallaxScales;
    public float smoothing = 1f;

    private Vector3 previousCamPos;

    void Start()
    {
        previousCamPos = transform.position;

        parallaxScales = new float[backgrounds.Length];
        for (int i = 0; i < backgrounds.Length; i++)
        {
            parallaxScales[i] = backgrounds[i].position.z * -1;
        }
    }

    void LateUpdate()
    {
        Vector3 camPos = Camera.main.transform.position;
        Vector3 camDeltaPos = camPos - previousCamPos;

        for (int i = 0; i < backgrounds.Length; i++)
        {
            float parallax = (camDeltaPos.x * parallaxScales[i]) / smoothing;
            Vector3 backgroundTargetPos = new Vector3(backgrounds[i].position.x + parallax, backgrounds[i].position.y, backgrounds[i].position.z);
            backgrounds[i].position = Vector3.Lerp(backgrounds[i].position, backgroundTargetPos, smoothing * Time.deltaTime);
        }

        previousCamPos = camPos;
    }
}
