using UnityEngine;
using UnityEngine.UI;

public class VolumeController : MonoBehaviour
{
    public Slider volumeSlider;

    private void Start()
    {
        // Load the current volume level from PlayerPrefs
        float volume = PlayerPrefs.GetFloat("volume", 1f);
        AudioListener.volume = volume;

        // Set the slider value to the current volume level
        volumeSlider.value = volume;
    }

    public void OnVolumeChanged(float volume)
    {
        // Set the volume level and save it to PlayerPrefs
        AudioListener.volume = volume;
        PlayerPrefs.SetFloat("volume", volume);
    }
    
    public void SetMusicVolume(float volume)
    {
        PlayerPrefs.SetFloat("MusicVolume", volume);
        // You can add additional code to adjust the music volume here if needed
    }
}