using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BigFishScript : MonoBehaviour
{
    public float speed = 2f;
    public float swimDistance = 4f;
    private bool facingRight = true;
    private Vector3 startPos;
    private Vector3 leftPos;
    private Vector3 rightPos;

    private void Start()
    {
        startPos = transform.position;
        leftPos = new Vector3(startPos.x - swimDistance / 2, startPos.y, startPos.z);
        rightPos = new Vector3(startPos.x + swimDistance / 2, startPos.y, startPos.z);
    }

    private void Update()
    {
        Vector3 targetPos = facingRight ? rightPos : leftPos;
        transform.position = Vector3.MoveTowards(transform.position, targetPos, speed * Time.deltaTime);

        if (transform.position.x > rightPos.x - 0.1f && facingRight)
        {
            Flip();
        }
        else if (transform.position.x < leftPos.x + 0.1f && !facingRight)
        {
            Flip();
        }
    }

    private void Flip()
    {
        facingRight = !facingRight;
        Vector3 theScale = transform.localScale;
        theScale.x *= -1;
        transform.localScale = theScale;
    }
}