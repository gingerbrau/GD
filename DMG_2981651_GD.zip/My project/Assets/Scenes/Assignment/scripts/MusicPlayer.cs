using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MusicPlayer : MonoBehaviour
{
    public AudioClip backgroundMusic;
    private AudioSource audioSource;

    private void Start()
    {
        audioSource = GetComponent<AudioSource>();
        audioSource.clip = backgroundMusic;
        audioSource.loop = true;
        audioSource.Play();
    }
    
    public void PlayMusic()
    {
        float musicVolume = PlayerPrefs.GetFloat("MusicVolume", 1f);
        // Use the musicVolume value to adjust the volume of your music
    }
}

