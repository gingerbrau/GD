using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AssPlayerScript : MonoBehaviour
{
    public float speed;
    public float burstSpeedMultiplier = 2f;
    public float burstDuration = 1f;

    private Rigidbody2D rb;
    private SpriteRenderer sr;
    private Animator animator;
    private float burstTimeRemaining = 0f;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        sr = GetComponent<SpriteRenderer>();
        animator = GetComponent<Animator>();
    }

    void Update()
    {
        // Check if the space bar is pressed
        if (Input.GetKeyDown(KeyCode.Space))
        {
            // Start the burst
            burstTimeRemaining = burstDuration;
        }

        float horizontal = Input.GetAxisRaw("Horizontal");
        float vertical = Input.GetAxisRaw("Vertical");

        Vector3 movement = new Vector3(horizontal, vertical).normalized;

        if (movement.x < 0)
        {
            sr.flipX = true;
        }
        else if (movement.x > 0)
        {
            sr.flipX = false;
        }

        // Apply the regular or burst speed depending on the remaining time
        float currentSpeed = speed;
        if (burstTimeRemaining > 0)
        {
            currentSpeed *= burstSpeedMultiplier;
            burstTimeRemaining -= Time.deltaTime;
        }

        rb.MovePosition(transform.position + movement * currentSpeed * Time.deltaTime);

        // Check if movement is solely on the y axis
        if (horizontal == 0 && Mathf.Abs(vertical) > 0)
        {
            animator.SetFloat("Speed", 0f);
        }
        else
        {
            animator.SetFloat("Speed", Mathf.Abs(horizontal));
        }
    }
    
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Bottle") || other.gameObject.CompareTag("Paper") || other.gameObject.CompareTag("BinBag"))
        {
            FindObjectOfType<ObjectGenerator>().ItemPickedUp(other.gameObject);
            other.gameObject.SetActive(false);
        }
    }
}
