using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.TextCore;

public class UITextController : MonoBehaviour
{
    public Transform playerTransform;
    public TMP_Text uiText;
    public RectTransform canvasRect;
    public int Score = 0;
    
    void Start()
    {
        uiText = GetComponent<TMP_Text>();
    }

    private void Update()
    {
// Set the anchor point to the bottom left corner
        uiText.rectTransform.anchorMin = new Vector2(0, 0);
        uiText.rectTransform.anchorMax = new Vector2(0, 0);

        // Set the position to be at the bottom left corner
        uiText.rectTransform.anchoredPosition = new Vector2(180, 40);
        uiText.text = ("Score: " + Score);
    }

}
