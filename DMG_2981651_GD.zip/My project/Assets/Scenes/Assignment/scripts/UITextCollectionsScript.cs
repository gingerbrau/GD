using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.TextCore;

public class UITextCollectionsScript : MonoBehaviour
{
    public TMP_Text uiText;
    public int numLeft = 0;

    void Start()
    {
        uiText = GetComponent<TMP_Text>();
        UpdateText();
    }

    public void UpdateText()
    {
        uiText.text = "Items Left: " + numLeft;
    }

    private void Update()
    {
        // Set the anchor point to the bottom left corner
        uiText.rectTransform.anchorMin = new Vector2(0, 0);
        uiText.rectTransform.anchorMax = new Vector2(0, 0);

        // Set the position to be at the bottom left corner
        uiText.rectTransform.anchoredPosition = new Vector2(750, 40);
    }
    
    public void SetNumLeft(int value) {
        numLeft = value;
        UpdateText();
    }
}

