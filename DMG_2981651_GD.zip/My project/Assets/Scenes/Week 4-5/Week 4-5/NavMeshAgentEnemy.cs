// I don't know why stunned wont work 

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class NavMeshAgentEnemy : MonoBehaviour
{
    public Transform goal;
    public Transform start;
    public float stunnedTime;
    public bool stunned;
    public float followDistance;
    public float moveSpeed;
    public Transform waypointA;
    public Transform waypointB;
    private bool movingTowardsWaypointA = true;

    public float stoppingDistance;

    private NavMeshAgent agent;
    // Start is called before the first frame update
    void Start()
    {
        //agent = GetComponent<UnityEngine.AI.NavMeshAgent>();
        //agent.destination = goal.position; 
        //agent.destination = waypointA.position;
        agent = GetComponent<NavMeshAgent>();
    }
    
    // Update is called once per frame
    void Update()
    {
        
        // Calculate the distance between the enemy and the player.
        float distance = Vector3.Distance(transform.position, goal.position);

        // Check if the player is within the follow distance.
        if (!stunned && distance <= followDistance && goal.position != start.position)
        {
            // Move the enemy towards the player.
            //transform.position = Vector3.MoveTowards(transform.position, goal.position, moveSpeed * Time.deltaTime);
            agent.destination = goal.position;
        }
        else if (!stunned || goal.position == start.position)
        {
            // Move the enemy between waypoints A and B.
            if (movingTowardsWaypointA)
            {
                agent.destination = waypointA.position;
                if (Vector3.Distance(transform.position, waypointA.position) <= stoppingDistance)
                {
                    movingTowardsWaypointA = false;
                    agent.destination = waypointB.position;
                }
            }

            else
            {
                agent.destination = waypointB.position;
                if (Vector3.Distance(transform.position, waypointB.position) <= stoppingDistance)
                {
                    movingTowardsWaypointA = true;
                    agent.destination = waypointA.position;
                }
            }
        }

    }
    
    IEnumerator Stunned()
    {
        print("Stunning for " + stunnedTime);
        stunned = true;
        agent.destination = transform.position;
        yield return new WaitForSeconds(stunnedTime); 
        stunned = false;
        agent.destination = movingTowardsWaypointA ? waypointA.position : waypointB.position;

    }
}