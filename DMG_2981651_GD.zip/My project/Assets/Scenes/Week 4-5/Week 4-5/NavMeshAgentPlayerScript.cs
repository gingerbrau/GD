using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class NavMeshAgentPlayerScript : MonoBehaviour
{

    public GameObject projectile;


    public NavMeshAgent agent;
    public Transform startPoint;

    // Start is called before the first frame update
    void Start()
    {
       agent = GetComponent<UnityEngine.AI.NavMeshAgent>();
       print(
           "Goal: Reach the other side of the stage without getting caught by an enemy. " +
           "Left click to move and right click to drop box's to stun the enemy.");
    }

    // Update is called once per frame
    void Update()
    {

        //Mouse Movement - when you click the left mouse button player moves to that point
        if (Input.GetMouseButtonDown(0))
        {
            Ray movePosition = Camera.main.ScreenPointToRay(Input.mousePosition);
            if (Physics.Raycast(movePosition, out var hitInfo))
            {
                agent.SetDestination(hitInfo.point);
            }
        }

        //when you right click, drop a projectile to stun the enemy
        if (Input.GetMouseButtonDown(1))
        {
            GameObject projectile = Instantiate(this.projectile, transform.position, Quaternion.identity);
        }
    }

    private void OnTriggerEnter(Collider col)
    {
        if (col.gameObject.tag == "Enemy")
        {
            transform.position = startPoint.position;
            print("Player caught!");
            agent.SetDestination(transform.position);
            //agent.SetDestination(null);
           
        }
        // NavMeshAgentEnemy enemy = col.gameObject.GetComponent<NavMeshAgentEnemy>();
        // if (enemy != null)
        // {
        //     // Move the player back to the start point.
        //     transform.position = startPoint.position;
        // }
    }
    

}
