using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class goalScript : MonoBehaviour
{
    public GameObject[] enemies;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnTriggerEnter(Collider col)
    {
        if (col.CompareTag("Player"))
        {
            print("You Won!");
            // Set all enemy GameObjects to inactive.
            foreach (GameObject enemy in enemies)
            {
                enemy.SetActive(false);
            }
        }
    }
}
